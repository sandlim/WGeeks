# analyze policies and claims data from NFIP for each county
# FEMA NFIP policies and claims stats from 
# (Policy & Claim Statistics for Flood Insurance)
# http://www.fema.gov/policy-claim-statistics-flood-insurance/policy-claim-statistics-flood-insurance/policy-claim-13


# analyze policies and claims data from NFIP for each county
# FEMA NFIP policies and claims stats from 
# (Policy & Claim Statistics for Flood Insurance)
# http://www.fema.gov/policy-claim-statistics-flood-insurance/policy-claim-statistics-flood-insurance/policy-claim-13

# required libraries
library(stringr)
library(ggplot2)
# required functions
source("/Users/sandar/Desktop/Climate test/nfip-master/analyze_policies.R") # function to preprocess policies data
source("/Users/sandar/Desktop/Climate test/nfip-master/analyze_claims.R") # function to preprocess claims data

# policies data
policies <- Fn_Analyze_Policies() 

# claims data
claims <- Fn_Analyze_Claims()  

# combine county data on policies and claims
all_data <- merge(policies, claims, by = c("state", "county"), all = TRUE)
# convert state and county names to be consistent with ggplot2
all_data$state <- tolower(all_data$state)
all_data$county <- tolower(all_data$county)
# remove " county" and " parish" from county names
all_data$county <- gsub(" county", "", all_data$county)
all_data$county <- gsub(" parish", "", all_data$county)

# geo referencing info on counties and states
geo_county <- map_data("county")
names(geo_county) <- c("long", "lat", "group", "order", "state", "county")
geo_state <- map_data("state")

# data for graphics
gfx_data <- merge(geo_county, all_data, by = c("state", "county"))
gfx_data <- gfx_data[order(gfx_data$order), ]
# discretise variables of interest
gfx_data$policies_gfx <- cut(gfx_data$policies, 
                             breaks = c(1, 30, 100, 300, 1000, 10000, 400000),
                             labels = c("1 - 30", "30 - 100", "100 - 300", 
                                        "300 - 1k", "1k - 10k", "10k - 400k"))
gfx_data$payments_gfx <- cut(gfx_data$total_pay/10^6, 
                             breaks = c(0, 0.05, 0.40, 1.7, 6.3, 50, 7300),
                             labels = c("0 - 50k", "50k - 400k", "400k - 1.7M", 
                                        "1.7M - 6.3M", "6.3M - 50M", "50M - 7.3B"))



# plot policies
plot_map <- ggplot(data = gfx_data) + 
  geom_polygon(aes(long, lat, group = group, fill = policies_gfx)) + 
  geom_path(data = geo_state, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Policies Per County", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Policies Per County")) +
  scale_fill_brewer(palette = "default")
print(plot_map)



# plot payments
plot_map_pay <- ggplot(data = gfx_data) + 
  geom_polygon(aes(long, lat, group = group, fill = payments_gfx)) + 
  geom_path(data = geo_state, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Payments Per County (USD)", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Payments Per County (USD)")) +
  scale_fill_brewer(palette = "RdYlBu")
print(plot_map_pay)




# plot payments for florida
gfx_data1<-subset(gfx_data,state=="florida")
geo_state1<-subset(geo_state,region=="florida")


plot_map1 <- ggplot(data = gfx_data1) + 
  geom_polygon(aes(long, lat, group = group, fill = payments_gfx)) + 
  geom_path(data = geo_state1, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Payments Per County (USD)", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Payments Per County (USD)")) +
  scale_fill_brewer(palette = "RdYlBu")
print(plot_map1)

# plot payments for florida pp
gfx_data1<-subset(gfx_data,state=="florida")
geo_state1<-subset(geo_state,region=="florida")


head(gfx_data1)
nrow(gfx_data1)
length(unique(gfx_data1$county))#64


map.county <- map_data('county')
counties   <- unique(map.county[,5:6])
flcounties <- counties[counties$region=="florida",]
head(flcounties,n=1)
nrow(flcounties) #67
flcounties$population <- (population_florida)

gfx_data1<-subset(gfx_data,state=="florida")
secondarray<-gfx_data1



for (i in 1:2496){
  for (j in 1:67){
  secondarray[i,17]<- ifelse(secondarray[i,2] ==flcounties[j,2],secondarray[i,14]/flcounties[j,3],0)
  }
}



gfx_data1$payments_gfx_pp <-ifelse(gfx_data1$county==flcounties$county,gfx_data1$payments_gfx/flcounties$population,0 )


plot_map1pp <- ggplot(data = gfx_data1) + 
  geom_polygon(aes(long, lat, group = group, fill = payments_gfx)) + 
  geom_path(data = geo_state1, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Payments Per County (USD)", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Payments Per Person (USD)")) +
  scale_fill_brewer(palette = "RdYlBu")
print(plot_map1pp)




















# required libraries
library(stringr)
library(ggplot2)

# required functions
source("/Users/sandar/Desktop/Climate test/nfip-master/analyze_policies.R") # function to preprocess policies data
source("/Users/sandar/Desktop/Climate test/nfip-master/analyze_claims.R") # function to preprocess claims data

# policies data
policies <- Fn_Analyze_Policies() 

# claims data
claims <- Fn_Analyze_Claims()  

# combine county data on policies and claims
all_data <- merge(policies, claims, by = c("state", "county"), all = TRUE)
fl_data <-subset(all_data, all_data$state=="FLORIDA")

# convert state and county names to be consistent with ggplot2
all_data$state <- tolower(all_data$state)
all_data$county <- tolower(all_data$county)
fl_data$county <- tolower(fl_data$county)
# remove " county" and " parish" from county names
all_data$county <- gsub(" county", "", all_data$county)
all_data$county <- gsub(" parish", "", all_data$county)
fl_data$county <- gsub(" county", "", fl_data$county)

# geo referencing info on counties and states
geo_county <- map_data("county")
fl_geo_county<-subset(geo_county, geo_county$region=="florida")
names(geo_county) <- c("long", "lat", "group", "order", "state", "county")
names(fl_geo_county) <- c("long", "lat", "group", "order", "state", "county")

geo_state <- map_data("state")

fl_data$policiespp <- fl_data$policies/(20.61*10^6)
fl_data$premiumpp <- fl_data$premium/(20.61*10^6)
fl_data$total_paypp <- fl_data$total_pay/(20.61*10^6)
fl_data$state<-"florida"



map('county', 'florida', fill = TRUE, col = palette())


library(ggplot2)
map.county <- map_data('county')
counties   <- unique(map.county[,5:6])
flcounties <- counties[counties$region=="florida",]
head(flcounties,n=1)

head(fl_data,n=1)

colnames(fl_data)<-c("region","subregion","policies","insurance","premium","total_loss","closed_loss","open_loss","cwop_loss","total_pay", "policiespp","premiumpp","total_paypp")
head(fl_data,n=1)


#This is where you'd select whatever you want to plot
# `Obesity` is the first thing to come to mind
# no offense meant to the people of the great state of Arkansas :)
# it's defined as a random uniform draw between 0-100 in the 3rd line below:

combined<-merge(fl_data,flcounties)

inspolicies_map <- data.frame(state_names=flcounties$region, 
                          county_names=flcounties$subregion, 
                          inspolicies= fl_data$policies)



library(ggplot2)
map.county <- map_data('county')
fl_county <- subset(map.county, region == "florida")
counties   <- unique(fl_county[,5:6])
head(counties)

head(fl_data)
df<-fl_data[,c("county","policies")]
#library(choroplethr)
#library(choroplethrMaps)

#county_choropleth(fl_data, title = "", legend = "", num_colors = 7,
                  #state_zoom = NULL, county_zoom = NULL, reference_map = FALSE)


plot_map <- ggplot(data = fl_data) + 
  geom_polygon(aes(long, lat)) + 
  geom_path(data = fl_county, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Policies Per capita", x = NULL, y = NULL)) +
  #guides(fill = guide_legend(title = "Policies Per capita")) +
  scale_fill_brewer(palette = "Accent")
print(plot_map)




# data for graphics

gfx_data <- merge(geo_county, all_data, by = c("state", "county"))
gfx_data <- gfx_data[order(gfx_data$order), ]
fl_gfx_data <- subset(gfx_data,gfx_data$state=="florida")
# discretise variables of interest
gfx_data$policies_gfx <- cut(gfx_data$policies, 
                             breaks = c(1, 30, 100, 300, 1000, 10000, 400000),
                             labels = c("1 - 30", "30 - 100", "100 - 300", 
                                        "300 - 1k", "1k - 10k", "10k - 400k"))
gfx_data$payments_gfx <- cut(gfx_data$total_pay/10^6, 
                             breaks = c(0, 0.05, 0.40, 1.7, 6.3, 50, 7300),
                             labels = c("0 - 50k", "50k - 400k", "400k - 1.7M", 
                                        "1.7M - 6.3M", "6.3M - 50M", "50M - 7.3B"))

# plot policies
plot_map <- ggplot(data = gfx_data) + 
  geom_polygon(aes(long, lat, group = group, fill = sys)) + 
  geom_path(data = geo_state, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Policies Per County", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Policies Per County")) +
  scale_fill_brewer(palette = "Accent")
print(plot_map)


# plot payments
plot_map <- ggplot(data = gfx_data) + 
  geom_polygon(aes(long, lat, group = group, fill = payments_gfx)) + 
  geom_path(data = geo_state, 
            aes(x = long, y = lat, group = group), 
            fill = NA, 
            na.rm = TRUE) +
  labs(list(title = "NFIP Payments Per County (USD)", x = NULL, y = NULL)) +
  guides(fill = guide_legend(title = "Payments Per County (USD)")) +
  scale_fill_brewer(palette = "Accent")
print(plot_map)

