library(zipcode)
alldata <- data("zipcode")

hey<- alldata[alldata$state=="FL"]
df <- df[!cond1,]
fl_cities <-unique(all_data$cities)
